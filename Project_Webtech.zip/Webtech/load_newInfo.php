<?php
require ("Database/dbconnect.php");
include ("Database/session.php");

?>

	<?php
		$sql = "select * from reg where password='".$_SESSION['login_password']."'";
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result)){
				echo "Name : ";
				//echo "<br>";
				echo $row['name'];
				echo "<br>";
				echo "<br>";
				echo "Email : ";
				echo $row['email'];
				echo "<br>";
				echo "<br>";
				echo "Gender : ";
				//echo "<br>";
				echo $row['gender'];
			

				
			}
		}

	?>
