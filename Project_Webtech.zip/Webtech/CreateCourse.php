<?php
require ("Database/dbconnect.php");
require_once ("Database/session.php");

?>
<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $CourseName = $_POST['c_name'];
    $CourseId = $_POST['cid'];

   // $Ins Name =$_POST[$login_session];
    $sql = "insert into course (CourseName,CourseId) values (' $CourseName ',' $CourseId')";
    mysqli_query($conn,$sql);

}

?>

<fieldset>
    <form>
    Course Name: <br>
    <input type="text" name="c_name" id="c_name" >

    <br>
    <br>
    Course Id: <br>
    <input type="text" name="cid" id="cid" >
    <br>
    <br>
    Instructor: <br>
        <td>: <?php echo $login_session; ?></td>
        <br>
        <br>


        <input type="submit" name="submit" id="submit" value="Create">






</fieldset>


