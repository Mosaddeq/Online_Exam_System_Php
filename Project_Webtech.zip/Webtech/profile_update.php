
<?php
	require_once ('Database/dbconnect.php');
	include ('Database/session.php');
	require_once ('includes/headerin.php');
	require_once ("includes/accountin.php");
?>

<?php
if(isset($_SESSION['email_check'])){

	//$conn = getConnection();
	$sql = "select * from reg where password='".$_SESSION['login_password']."'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
?>
<html>
<head>

<script
  	src="https://code.jquery.com/jquery-3.3.1.min.js"
  	integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  	crossorigin="anonymous"></script>
<script>
		//jquery
		$(document).ready(function() {

			$("#newinfo").click(function() {
				$.get("load_newInfo.php",function(data,status){
					$("#info").html(data); 
					alert(status);
				});
			});
	
		});

	</script>
</head>
<body>

    <legend><b>EDIT PROFILE</b></legend>
	<form method="POST" action="updateProfile.php" >
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input id="name" name="name" type="text" value="<?=$row['name']?>"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input id="email" name="email" type="email" value="<?=$row['email']?>">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>				
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td>   
					<input id="gender" name="gender"  value='Male' type="radio" <?php if($row['gender']=="male"){echo "checked";}?>   >Male
					<input id="gender" name="gender" value='Female' type="radio" <?php if($row['gender']=="female"){echo "checked";}?> >Female
					
				</td>
				
			</tr>		
			
		</table>
		<hr/>
		<input type="submit" value="Update" name="update" id="update" >		

	</form>
	</fieldset>


	<input type="submit" value="Show Updated Information" id="newinfo" >
   <br>
   <br>
   <p id="info"> </p>
	
</body>
	</html>
<?php

}else{
    header("location: login.php");
}
?>