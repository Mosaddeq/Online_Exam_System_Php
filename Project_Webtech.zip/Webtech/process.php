<?php
require ("Database/dbconnect.php");

session_start(); 
//check to see if score is set
if(!isset($_SESSION['score'])){
    $_SESSION['score'] = 0; //set score //super global
}

//question number == n ,to get from post
if($_SERVER['REQUEST_METHOD']=='POST'){
    $number = $_POST['number'];
    $selected_choice = $_POST['choice']; //clicked answer comming from name attribute =choice from question
    $next = $number+1 ;
    


if($number == 1) {
    $_SESSION["score"] = 0;  //the score keeps adding to the previous scores. so if the qst no. is 1/retake score will be automatically zero :)
   }

//get total questions
$sql =("select * from questions");
$result = mysqli_query($conn,$sql);
$total = mysqli_num_rows($result); //total no. question



//get correct choice

$query="select * from choices where question_number = $number AND is_correct = 1";

$results= mysqli_query($conn,$query); //get result

//get row
$row = mysqli_fetch_assoc($results); 
//
$correct_choice = $row['id'];

//compare
if($correct_choice == $selected_choice){
    //answer is correct 
     $_SESSION['score']++;
}


//whether its the last statement or not
if ($number == $total){
    header("Location: final.php");
    exit();
}
else {
    header("Location: question.php?n=".$next); //n == the next value which means next question
}
}
?>