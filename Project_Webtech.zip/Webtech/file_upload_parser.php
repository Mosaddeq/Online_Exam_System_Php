<?php 

//file_uploads == On;
//include ("includes/headerin.php");
//include ("includes/accountin.php");
require ("Database/dbconnect.php");



	$file=$_FILES["file"]["name"];  //$_files for file types
	$tmp_name=$_FILES["file"]["tmp_name"]; //move_uploaded_file funct. only accepts 2 parameters .
	//$fileSize =$_FILES["file"]["size"];
	//$fileType =$_FILES["file"]["type"];										//so tmp_name is for that purpose to temporarily hold the file*/
	$path="uploads/".$file;  //to which folder file to be saved which is saved in $file var
	$file1=explode(".",$file); //to check extension after '.'
	$ext=$file1[1];
	//$allowed=array('mp3',"jpg","png","gif","pdf","wmv","pdf","zip","txt","pptx");

	$sql="insert into upload (file) value('$file')";



	move_uploaded_file($tmp_name,$path);

 	 //function through which file is uploaded
	//mysqli_query();
	mysqli_query($conn,$sql);
	
	




?>


