</td>
    </tr>
    <tr>
        <td colspan="2" align="center">
            Copyright &copy; 2018
        </td>
    </tr>
</table>