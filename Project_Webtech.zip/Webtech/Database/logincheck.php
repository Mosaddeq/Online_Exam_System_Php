<?php
require ("Database/dbconnect.php");
session_start();
if($_SERVER['REQUEST_METHOD']=='POST')
{


    $email = $_POST['email'];
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM reg WHERE email='$email' and password = '$pass'"; //datas for normal users
    $sqli = "SELECT * FROM admin WHERE email='$email' and password = '$pass'"; //for admin only
    $result = mysqli_query($conn,$sql);
    $resulti = mysqli_query($conn,$sqli); //admin

    $count = mysqli_num_rows($result);
    $row = mysqli_fetch_assoc($result); //fetches a result row as an associative array.
    //$counti = mysqli_num_rows($resulti); //admin
    //$row = mysqli_fetch_assoc($resulti);
    $counti = mysqli_num_rows($resulti);
    $rowi = mysqli_fetch_assoc($resulti);
    if($email == "" || $pass == ""){
        header("location: login.php?status=error");
    }
    if(!count($row)){
        header("location: login.php?status=error");
    }

    if(count($row)>0 && $row['uType']=='Instructor')
    {
        if(!empty($_POST["remember"])) {
            setcookie("email", $email, time() + (60*60*24*7)); //setting cookies for 1 week
            setcookie("pass", $pass, time() + (60*60*24*7));
        }

            // $_SESSION['name_check']=$name;      //initializing sessions
        $_SESSION['email_check']=$email;      //initializing sessions
        $_SESSION['login_password']=$pass;
        $_SESSION['uType']= 'Instructor';
        header('location: instructor_home.php');
    }
    else if(count($row)>0 && $row['uType']=='Student')
    {
        if(!empty($_POST["remember"])) {
            setcookie("email", $email, time() + (60*60*24*7)); //setting cookies
            setcookie("pass", $pass, time() + (60*60*24*7));
        }
        //$_SESSION['name_check']=$name;      //initializing sessions
        $_SESSION['email_check']=$email;
        $_SESSION['login_password']=$pass;
        $_SESSION['uType']= 'Student';
        header('location: student_home.php');
    }
    if(count($rowi)>0 && $rowi['uType']=='Admin')
    {
        //echo 'boo';sssssssssssssssssssssss
        $_SESSION['email_check']=$email;
        $_SESSION['login_password']=$pass;
        $_SESSION['utype']= 'Admin';
        header('location: admin_home.php');
    }

}
?>