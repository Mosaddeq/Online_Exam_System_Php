<?php
require ("Database/dbconnect.php");
//TODO: link file uploading with question

if (isset($_POST['submit'])){
   // echo "sub";
    //get post var and assign them into reg vars
    $question_number = $_POST['question_number'];
    $question_text =  $_POST['question_text'];
    $correct_choice =$_POST['correct_choice'];
    //taking choices in a arrary.otherwise if a choice is blank it wont insert values cuz not matching of parameters
    $choices = array();
    $choices[1]= $_POST['choice1'];
    $choices[2]= $_POST['choice2'];
    $choices[3]= $_POST['choice3'];
    $choices[4]= $_POST['choice4'];
    $choices[5]= $_POST['choice5'];
   
    $sql = "insert into questions (question_number,text) values ('$question_number','$question_text')"; 

    $row = mysqli_query($conn,$sql);
    //checking to make sure is qst was inserted
    if($row){
        foreach($choices as $choice => $value){
            if($value != ''){
                if($correct_choice == $choice){
                    $is_correct = 1;
                }else{
                    $is_correct = 0;
                }
                //choice query
                $sql = "insert into choices (question_number,is_correct,text) values ('$question_number','$is_correct','$value')";
                
                //run above

                $row = mysqli_query($conn,$sql);

                //validate insert
                if($row){
                    continue;
                }
                else{
                    die("Connection Error!".mysqli_connect_error());
                }
            }
        }
        $msg ='question has been added';
    }
    $query =("select * from questions");
$results = mysqli_query($conn,$query);
$total = mysqli_num_rows($results);
$next = $total+1;


}

   
?>