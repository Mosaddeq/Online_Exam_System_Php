

?>


<form enctype="multipart/form-data" method="post" action="#">

File Upload:<input type="file" name="file">
<input type="submit" name="submit" value="upload">
<br>
<a href="instructor_home.php">Back</a>
</form