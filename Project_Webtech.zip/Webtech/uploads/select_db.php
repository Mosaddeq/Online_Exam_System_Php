<?php

	$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="webtec";
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "select * from user";
	$result = mysqli_query($conn, $sql);
	
	if(mysqli_num_rows($result)>0){
		
		while($row=mysqli_fetch_assoc($result)){
			echo "ID: ".$row['id']."<br/>NAME: ".$row['name']."<br/>PASSWORD: ".$row['password']."<br/><br/>";
		}
		
	}else{
		echo "Result not found!";
	}

	mysqli_close($conn);
?>