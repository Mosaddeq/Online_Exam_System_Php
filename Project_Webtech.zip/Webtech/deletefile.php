<?php
require ("Database/session.php");
require ("Database/dbconnect.php");
include ("includes/headerin.php");
include ("includes/accountin.php");
include ("searchData.php");

$file= $_GET['file'];

$sql="delete from upload where file = '$file'";
$rs = mysqli_query($conn,$sql);
?>