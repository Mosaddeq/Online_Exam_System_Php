<html lang = "en">
<head>
</head>

<body>
<form id="form" method = "post" action="picupload.php" enctype="multipart/form-data" target="iframe" ></form>
<iframe name="iframe"> </iframe>
</body>
</html>