<?php

require('Database/dbconnect.php');

$data 	= $_GET['data'];
//$conn = getConnection();

$sql = "select * from upload where file like '%$data%'";

$result = mysqli_query($conn, $sql);

echo  "<table width='100%'>";
while($row = mysqli_fetch_assoc($result)){

    echo  "<tr border=1> <td><b>id: </b></td> <td>".$row['id']."</td>
                    <td><b>file: </b></td> <td>".$row['file']."</td>
					
                    <td>      </td> <td><a href='deletefile.php?file=".$row['file']."'>Delete</a></td>
              </tr>";
}
echo "</table>";
?>